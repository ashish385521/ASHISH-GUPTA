(function(){
// 
$('#gallery').hide();
	$('.contentrightcaption').hide();

	$( window ).load(function() {
		$('#gallery').show('slow');
	});


	$('li').click(function(e) {
		e.preventDefault();
		var href = $(this).find('a').attr('href');
		var src = $(this).find('img').attr('src');
		var caption = $(this).find('img').attr('title');
		
		// console.log('href:'+href);
		// console.log('src:'+src);
		// console.log('caption:'+caption);
		$('.contentrightpreview').fadeToggle(500, function(){
			$('.preload_area').html('<img src="'+href+'"/>');
			$('.contentrightpreview')
			.html( '<a class="overlaylink" href="'+href+'" title="'+caption+'" style="background-image:url('+src+');"><img src="'+href+'"></a>' ).show();
		} );
		$('.contentrightcaption').slideUp(caption);
		$('.contentrightcaption').slideDown( function(){
		$('.contentrightcaption').html(caption);

		setFancyboxLink();
		});
				
	});

})();

//Initialize first picture in preview area
		var first_href = $('li').find('a').first().attr('href');
		var first_src = $('li').find('img').first().attr('src');
		var first_caption = $('li').find('img').first().attr('title');

			$('.contentrightpreview').fadeToggle(500, function(){
			$('.preload_area').html('<img src="'+first_href+'"/>');
			$('.contentrightpreview')
			.html( '<a class="overlaylink" href="'+first_href+'" title="'+first_caption+'" style="background-image:url('+first_src+');"><img src="'+first_href+'"></a>' ).show();
		} );
		$('.contentrightcaption').slideUp(first_caption);
		$('.contentrightcaption').slideDown( function(){
		$('.contentrightcaption').html(first_caption);

		setFancyboxLink();
		});
		

function setFancyboxLink(){
	$('a.overlaylink').fancybox({
		'titlePosition' : 'over',
		'overlayColor'  : '#000',
		'overlayOpacity': 0.8,
		'transitionOut' : 'elastic',
		'transitionIn'  : 'elastic',
		'autoScale'     : true
	})
}